package com.example.tp03desenvolvimento

import java.io.Serializable

class Usuario(
        var nome:String = "",
        var pontuacao: Int = 0
):Serializable